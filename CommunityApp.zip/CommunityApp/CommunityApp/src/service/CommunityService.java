package service;

public class CommunityService {
    
}
