package model;

public class Request {
    
}
