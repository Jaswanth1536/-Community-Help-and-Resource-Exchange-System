package model;

public class Response {
    
}
