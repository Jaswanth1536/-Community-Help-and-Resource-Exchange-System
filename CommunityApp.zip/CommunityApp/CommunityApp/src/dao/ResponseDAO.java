package dao;

public class ResponseDAO {
    
}
